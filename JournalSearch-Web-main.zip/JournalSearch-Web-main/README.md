# JournalSearch-Web
Frontend for Journal Website
